package com.arena.msg.apinotification;

import com.arena.msg.apinotification.business.EmailService;
import com.arena.msg.apinotification.business.NotificationService;
import com.arena.msg.apinotification.model.EmailMessage;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.platform.commons.annotation.Testable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

@SpringJUnitConfig
public class NotificationServiceTest {


    @InjectMocks
    NotificationService notificationService;

    @Mock
    EmailService emailService;

    @Test
    public void testNotificationService(){

        //Sample Test for code covergare for main service
        EmailMessage emailMessage= new EmailMessage();
        emailMessage.setMessage("Test");
        emailMessage.setToAddress("Test@email");
        emailMessage.setFromAddress("Testing@itarena.com");

        Mockito.when(emailService.sendApiMessage(Mockito.any(),Mockito.any())).thenReturn(emailMessage);

        String actual=notificationService.sendNotification("Testing","Test@email","Email");

        String expected="EmailMessage(message=Test, toAddress=Test@email, fromAddress=Testing@itarena.com)";
        Assertions.assertEquals(expected,actual);

        //Similarly we can do code coverage for all class and for e2e we can write kind of API intergation testing
    }
}
