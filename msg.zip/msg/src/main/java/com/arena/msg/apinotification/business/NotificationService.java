package com.arena.msg.apinotification.business;

import com.arena.msg.apinotification.model.EmailMessage;
import com.arena.msg.apinotification.model.SMSMessage;
import com.arena.msg.apinotification.model.WhatsAppMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {

    @Autowired
    EmailService emailService;

    @Autowired
    SMSService smsService;

    @Autowired
    WhatsappService whatsappService;

    /**
     * Send notification based on channel
     *
     * @param message the message
     * @param recipient the address
     * @param channel the channel
     * @return response
     */
    public  String sendNotification(String message, String recipient, String channel) {

        switch(channel){
            case "Email":{
                EmailMessage response=emailService.sendApiMessage(message,recipient);
                return response.toString();
            }
            case "SMS":{
                SMSMessage response=smsService.sendApiMessage(message,recipient);
                return response.toString();
            }
            case "Whatsapp":{
                WhatsAppMessage response=whatsappService.sendApiMessage(message,recipient);
                return response.toString();
            }
            default:
                break;

        }
        return null;
    }
}
