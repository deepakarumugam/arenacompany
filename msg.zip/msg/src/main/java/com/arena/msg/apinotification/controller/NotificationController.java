package com.arena.msg.apinotification.controller;

import com.arena.msg.apinotification.business.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/notification")
public class NotificationController {


    @Autowired
    private NotificationService notificationService;

    @PostMapping("/test")
    public String sendMessage(@RequestParam String message,@RequestParam String recipient, @RequestParam String channel){
        // We can have pattern check in request param as we has valid checks and values consist of only checks.
        String response= notificationService.sendNotification(message,recipient,channel);
        //Sample Response we can type cast or use mapstruct to send response in needed format.
        return response;
    }

}
