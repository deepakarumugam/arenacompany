package com.arena.msg.apinotification.business;

import com.arena.msg.apinotification.model.SMSMessage;
import com.arena.msg.apinotification.model.WhatsAppMessage;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class WhatsappService {
    @Value("/mock")
    public WhatsAppMessage   sendApiMessage(String message, String recipient) {

        WhatsAppMessage whatsAppMessage= new WhatsAppMessage();
        whatsAppMessage.setMessage(message);
        whatsAppMessage.setToAddress(recipient);
        whatsAppMessage.setFromAddress("Testing@itarena.com");
        //Used Rest Template to reach adaptor and send message

        return whatsAppMessage;
    }
}
