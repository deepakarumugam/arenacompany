package com.arena.msg.apinotification.model;

import com.arena.msg.apinotification.business.NotificationService;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class EmailMessage {

    /**
     *  The Message
     */
    private String message;
    /**
     *  The to address
     */
    private String toAddress;

    /**
     *  The from
     */
    private String fromAddress;
}
