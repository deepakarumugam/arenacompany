package com.arena.msg.apinotification.business;

import com.arena.msg.apinotification.model.EmailMessage;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    public EmailMessage sendApiMessage(String message, String recipient) {

        EmailMessage emailMessage= new EmailMessage();
        emailMessage.setMessage(message);
        emailMessage.setToAddress(recipient);
        emailMessage.setFromAddress("Testing@itarena.com");

        //Used Rest Template to reach adaptor and send message
        return emailMessage;
    }
}
