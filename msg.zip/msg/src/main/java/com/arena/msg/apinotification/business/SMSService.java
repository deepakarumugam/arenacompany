package com.arena.msg.apinotification.business;

import com.arena.msg.apinotification.model.EmailMessage;
import com.arena.msg.apinotification.model.SMSMessage;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class SMSService {
    @Value("/mock")
    public SMSMessage sendApiMessage(String message, String recipient) {

        SMSMessage smsMessage= new SMSMessage();
        smsMessage.setMessage(message);
        smsMessage.setToAddress(recipient);
        smsMessage.setFromAddress("Testing@itarena.com");
        //Used Rest Template to reach adaptor and send message

        return smsMessage;
    }
}
